export const pluginId = 'typescript-tslint-plugin';
export const TSLINT_ERROR_CODE = 1;
export const TSLINT_ERROR_SOURCE = 'tslint';