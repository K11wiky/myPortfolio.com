let t: Array<string> = new Array<string>();

console.log(t);
