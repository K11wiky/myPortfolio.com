module.exports = {
    "rules": {
        "array-type": true,
        "quotemark": 1 === 1
    }
}