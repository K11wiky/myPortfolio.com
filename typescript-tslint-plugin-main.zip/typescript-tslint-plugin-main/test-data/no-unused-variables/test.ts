export const b = 1;

const a = 1;