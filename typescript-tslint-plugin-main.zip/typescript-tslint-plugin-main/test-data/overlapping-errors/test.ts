import {
    isEqual,
    isEmpty
} from "lodash";

console.log(isEmpty, isEqual); 