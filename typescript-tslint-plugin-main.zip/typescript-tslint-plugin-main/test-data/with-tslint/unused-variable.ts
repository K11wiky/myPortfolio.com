export const _ = 1;

const unused = 1;