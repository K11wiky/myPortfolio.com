// test a jsRule trippe equals, tripple equals quick fix is vscode-tslint contributed
   let a = 2;

    if (a == 2) {
 
    }

    [1, 2 ].map( num => console.log(num) );