
var anakin: string = "jedi";

console.log(`variable is used:${anakin}`);