// missing semicolon warning supressed to due ignoreDefinitionFiles setting
interface F {
    f1()
    f2()
}