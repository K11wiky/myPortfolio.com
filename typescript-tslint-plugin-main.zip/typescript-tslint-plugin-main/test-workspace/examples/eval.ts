// There is no TSLint fix for the "no-eval" rule,
// but the "disable rule" fix is still available.
let x = eval("1 + 1");
