[1, 2 ].map( num => console.log(num) );
   