let t: Array<string> = new Array<string>();
let x: Array<string> = new Array<string>();

console.log(t);
   