// VS Code provided fix
let s = 'quotemark';

console.log(s);