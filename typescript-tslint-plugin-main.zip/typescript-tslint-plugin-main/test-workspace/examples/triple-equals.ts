// VS Code provided fix for === not supported when using the tslint-language-service
let a = 3;

if (a == 3) {
    console.log(a);
}

if (a != 3) {
    console.log(a);
}