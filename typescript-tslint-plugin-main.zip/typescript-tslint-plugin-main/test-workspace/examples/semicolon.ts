let test1: string
console.log(`use ${test1}`)