// !!! no-unused-variable is currently not supported pls see: https://github.com/palantir/tslint/issues/2649
import {  } from "diff";

import { A, B } from "parse-json";

console.log(`use ${A}`);