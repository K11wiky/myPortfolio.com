import {B, A, C} from "diff";
import {D, E} from "diff";

console.log(`use ${A} ${B} ${C} ${D}, ${E}`);