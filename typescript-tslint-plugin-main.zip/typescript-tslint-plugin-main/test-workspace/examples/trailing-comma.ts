// a comma is missing at the end

let test = {
  lastName: "smith",
  missAComma: "mis"
};

let test2 = {
  lastName: "smith",
  missAComma: "mis"
};

console.log(test, test2);